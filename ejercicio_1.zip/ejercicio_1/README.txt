README.TXT

EJERCICIO 1

1) Los datos consultados respecto al valor de cambio de Euro a Dolares son los siguientes:

2021-08-23	1.1743
2021-08-22	1.1697
2021-08-20	1.1696
2021-08-19	1.1674
2021-08-18	1.1710


2) Los datos consultados en el punto (1) fueron cargados en la base de datos con la siguiente información:

HOSTNAME: 	ejercicio2-instancia.cryssnu9ajdn.us-east-2.rds.amazonaws.com
PORT: 		3306 
USERNAME:	ejercicio2admin
PASSWORD:	8XLY3NHHU6WH6ODZMCDj
SCHEMA:		ejercicio1db
TABLE:		ejercicio1_table

3) Descomprimir el proyecto ejercicio_1.zip

4) Abrir el directorio descomprimido ejercicio_1 con Visual Studio Code

5) Crear un Terminal Integrado (Ctrl + Shift + P)

6) Ejecutar: npm run dev

7) Abrir un browser y copiar el link:

	http://localhost:3000/

	Se despliegan todos los registros de la tabla

8) Abrir un browser y copiar el link:

	http://localhost:3000/2021-08-20

	Se depliega el registro correspondiente a la fecha 2021-08-20

9) Validar la ejecución y la invocación al webhook especificado
