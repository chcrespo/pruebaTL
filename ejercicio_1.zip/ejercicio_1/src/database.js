const mysql = require('mysql');

const mysqlConnection = mysql.createConnection({
    host: 'ejercicio2-instancia.cryssnu9ajdn.us-east-2.rds.amazonaws.com',
    user: 'ejercicio2admin', 
    password: '8XLY3NHHU6WH6ODZMCDj',
    database: 'ejercicio1db'
});

mysqlConnection.connect(function (err) {
    if(err) {
        console.log(err);
        return;
    } else {
        console.log('Base de Datos conectada.');
    }
});

module.exports = mysqlConnection;