const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');

const mysqlConnection = require('../database');

router.get('/', (req, res) => {
    mysqlConnection.query('select * from ejercicio1_table', (err, rows, fields) => {
        if(!err) {
             res.json(rows);
        } else {
            console.log(err);
        }
    });
});

router.get('/:fecha', (req, res) => {
    const { fecha }  = req.params;
    mysqlConnection.query('select * from ejercicio1_table where fecha = ?', [fecha], (err, rows, fields) => {
        if(!err) {
            fetch('https://webhook.site/4ed54cff-41ba-423e-9f46-b2c87408daf9', {
                method: "POST",
                body: JSON.stringify(rows[0]),
                headers: {"Content-type": "application/json"}
              })
              .then(response => response.json()) 
              .then(json => console.log(json));         
              res.json(rows[0]);
         } else {
            console.log(err);
        }
    });
});

module.exports = router;